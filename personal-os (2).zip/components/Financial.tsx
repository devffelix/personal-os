import React, { useState, useMemo } from 'react';
import { Transaction, TransactionType, FinancialSubCategory } from '../types';
import { Plus, ChevronLeft, ChevronRight, TrendingUp, TrendingDown, DollarSign, X, Trash2, Check, Pencil } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface FinancialProps {
  transactions: Transaction[];
  setTransactions: (transactions: Transaction[]) => void;
}

const CATEGORIES = [
  'Mercado', 'Transporte', 'Aluguel', 'Contas', 'Delivery', 
  'Viagem', 'Roupas', 'Lazer', 'Eletrônicos', 'Saúde', 
  'Educação', 'Salário', 'Investimentos', 'Freelance', 'Outros'
];

const SUB_CATEGORIES: { value: FinancialSubCategory; label: string; type: TransactionType }[] = [
  { value: 'custo_fixo', label: 'Custo Fixo', type: 'expense' },
  { value: 'custo_variavel', label: 'Custo Variável', type: 'expense' },
  { value: 'lazer', label: 'Lazer', type: 'expense' },
  { value: 'ganho_fixo', label: 'Ganho Fixo', type: 'income' },
  { value: 'ganho_variavel', label: 'Ganho Variável', type: 'income' },
  { value: 'ganho_passivo', label: 'Ganho Passivo', type: 'income' },
];

const formatMoney = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

interface TransactionItemProps {
  t: Transaction;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (t: Transaction) => void;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ t, onToggle, onDelete, onEdit }) => (
  <div className={`group flex items-center p-3 bg-white border rounded-lg transition-all ${t.completed ? 'opacity-60 border-stone-100' : 'border-stone-200 shadow-sm'}`}>
      {/* Status Checkbox */}
      <button 
          onClick={(e) => { e.stopPropagation(); onToggle(t.id); }}
          className={`mr-3 w-5 h-5 rounded-full border flex items-center justify-center transition-colors flex-shrink-0 ${
              t.completed 
              ? (t.type === 'income' ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-stone-400 border-stone-400 text-white')
              : 'border-stone-300 hover:border-stone-400 text-transparent'
          }`}
      >
          <Check className="w-3 h-3" strokeWidth={3} />
      </button>

      {/* Date */}
      <div className="flex flex-col items-center mr-4 w-8 flex-shrink-0">
          <span className="text-[10px] text-stone-400 font-medium uppercase">{new Date(t.date).toLocaleDateString('pt-BR', { weekday: 'short' }).slice(0, 3)}</span>
          <span className="text-sm font-semibold text-stone-700">{t.date.split('-')[2]}</span>
      </div>

      {/* Details */}
      <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onEdit(t)}>
          <p className={`text-sm font-medium truncate ${t.completed ? 'text-stone-500 line-through' : 'text-stone-800'}`}>{t.description}</p>
          <div className="flex items-center gap-2">
               <span className="text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded">{t.category}</span>
               <span className="text-[10px] text-stone-400 capitalize">{SUB_CATEGORIES.find(s => s.value === t.subCategory)?.label}</span>
          </div>
      </div>

      {/* Amount */}
      <div className="text-right mx-4">
          <span className={`text-sm font-semibold ${t.type === 'income' ? 'text-emerald-600' : 'text-stone-800'}`}>
              {formatMoney(t.amount)}
          </span>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button onClick={(e) => { e.stopPropagation(); onEdit(t); }} className="p-1.5 text-stone-300 hover:text-stone-600 transition-colors">
            <Pencil className="w-4 h-4" />
        </button>
        <button onClick={(e) => { e.stopPropagation(); onDelete(t.id); }} className="p-1.5 text-stone-300 hover:text-red-400 transition-colors">
            <Trash2 className="w-4 h-4" />
        </button>
      </div>
  </div>
);

const Financial: React.FC<FinancialProps> = ({ transactions, setTransactions }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>('expense');
  const [category, setCategory] = useState('Mercado');
  const [subCategory, setSubCategory] = useState<FinancialSubCategory>('custo_variavel');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  // Navigation
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const currentMonthKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
  
  // Filter Data
  const monthlyTransactions = useMemo(() => {
    return transactions.filter(t => t.date.startsWith(currentMonthKey)).sort((a,b) => a.date.localeCompare(b.date)); // Sort ascending for list view
  }, [transactions, currentMonthKey]);

  const incomes = monthlyTransactions.filter(t => t.type === 'income');
  const expenses = monthlyTransactions.filter(t => t.type === 'expense');

  // Metrics
  const metrics = useMemo(() => {
    const totalIncome = incomes.reduce((acc, curr) => acc + curr.amount, 0);
    const totalExpense = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    
    const fixedCost = expenses.filter(t => t.subCategory === 'custo_fixo').reduce((acc, curr) => acc + curr.amount, 0);
    const variableCost = expenses.filter(t => t.subCategory === 'custo_variavel').reduce((acc, curr) => acc + curr.amount, 0);
    const leisureCost = expenses.filter(t => t.subCategory === 'lazer').reduce((acc, curr) => acc + curr.amount, 0);

    const fixedIncome = incomes.filter(t => t.subCategory === 'ganho_fixo').reduce((acc, curr) => acc + curr.amount, 0);
    const passiveIncome = incomes.filter(t => t.subCategory === 'ganho_passivo').reduce((acc, curr) => acc + curr.amount, 0);

    return {
      totalIncome,
      totalExpense,
      balance: totalIncome - totalExpense,
      fixedCost,
      variableCost,
      leisureCost,
      fixedIncome,
      passiveIncome
    };
  }, [incomes, expenses]);

  // Reset Form
  const resetForm = () => {
      setDescription('');
      setAmount('');
      setType('expense');
      setCategory('Mercado');
      setSubCategory('custo_variavel');
      // Don't reset date significantly to improve UX
      setEditingId(null);
      setIsAdding(false);
  };

  // Handlers
  const startEdit = (t: Transaction) => {
    setDescription(t.description);
    setAmount(t.amount.toString());
    setType(t.type);
    setCategory(t.category);
    setSubCategory(t.subCategory);
    setDate(t.date);
    setEditingId(t.id);
    setIsAdding(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount) return;

    if (editingId) {
        // Update Existing
        const updatedTransactions = transactions.map(t => {
            if (t.id === editingId) {
                return {
                    ...t,
                    description,
                    amount: Number(amount),
                    type,
                    category,
                    subCategory,
                    date
                };
            }
            return t;
        });
        setTransactions(updatedTransactions);
    } else {
        // Create New
        const newTransaction: Transaction = {
          id: uuidv4(),
          description,
          amount: Number(amount),
          type,
          category,
          subCategory,
          date,
          completed: false
        };
        setTransactions([...transactions, newTransaction]);
    }

    resetForm();
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja apagar esta movimentação?')) {
      setTransactions(transactions.filter(t => t.id !== id));
    }
  };

  const toggleStatus = (id: string) => {
      setTransactions(transactions.map(t => 
        t.id === id ? { ...t, completed: !t.completed } : t
      ));
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fade-in pb-10">
      
      {/* Header & Month Selector */}
      <div className="flex items-center justify-between sticky top-0 bg-stone-50 py-4 z-10">
        <div className="flex items-center gap-4">
          <button onClick={prevMonth} className="p-2 hover:bg-stone-100 rounded-full text-stone-500"><ChevronLeft className="w-5 h-5" /></button>
          <h2 className="text-2xl font-medium text-stone-800 capitalize">
            {currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
          </h2>
          <button onClick={nextMonth} className="p-2 hover:bg-stone-100 rounded-full text-stone-500"><ChevronRight className="w-5 h-5" /></button>
        </div>
        <button 
          onClick={() => { resetForm(); setIsAdding(true); }}
          className="flex items-center px-4 py-2 bg-stone-800 text-white text-sm font-medium rounded-md hover:bg-stone-700 transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4 mr-2" /> Nova Transação
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Balance */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 shadow-sm">
            <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-medium text-stone-400 uppercase">Saldo Previsto</span>
                <DollarSign className={`w-4 h-4 ${metrics.balance >= 0 ? 'text-emerald-500' : 'text-red-500'}`} />
            </div>
            <div className={`text-2xl font-semibold ${metrics.balance >= 0 ? 'text-stone-800' : 'text-red-600'}`}>
                {formatMoney(metrics.balance)}
            </div>
        </div>

        {/* Expenses */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 shadow-sm">
            <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-medium text-stone-400 uppercase">Saídas Totais</span>
                <TrendingDown className="w-4 h-4 text-red-400" />
            </div>
            <div className="text-2xl font-semibold text-stone-800">
                {formatMoney(metrics.totalExpense)}
            </div>
            <div className="flex gap-2 mt-2">
                <span className="text-[10px] text-stone-500">Fixo: {formatMoney(metrics.fixedCost)}</span>
                <span className="text-[10px] text-stone-400">|</span>
                <span className="text-[10px] text-stone-500">Var: {formatMoney(metrics.variableCost + metrics.leisureCost)}</span>
            </div>
        </div>

         {/* Passive Income */}
         <div className="bg-white p-4 rounded-lg border border-stone-200 shadow-sm">
            <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-medium text-stone-400 uppercase">Entradas Totais</span>
                <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-semibold text-emerald-600">
                {formatMoney(metrics.totalIncome)}
            </div>
             <div className="flex gap-2 mt-2">
                <span className="text-[10px] text-stone-500">Passivo: {formatMoney(metrics.passiveIncome)}</span>
            </div>
        </div>

        {/* ROI / Savings Rate (Simulated) */}
        <div className="bg-white p-4 rounded-lg border border-stone-200 shadow-sm flex flex-col justify-center items-center text-center">
            <span className="text-xs font-medium text-stone-400 uppercase mb-1">Taxa de Poupança</span>
            <div className="text-3xl font-light text-stone-800">
                {metrics.totalIncome > 0 ? Math.round(((metrics.totalIncome - metrics.totalExpense) / metrics.totalIncome) * 100) : 0}%
            </div>
        </div>
      </div>

      {/* Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Income Column */}
          <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                  <h3 className="font-medium text-stone-500 uppercase text-xs tracking-wider flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-emerald-500" /> Entradas / Receitas
                  </h3>
                  <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{formatMoney(metrics.totalIncome)}</span>
              </div>
              <div className="space-y-2">
                  {incomes.length === 0 ? (
                      <div className="text-center py-10 border border-dashed border-stone-200 rounded-lg">
                          <p className="text-xs text-stone-400">Nenhuma entrada cadastrada.</p>
                      </div>
                  ) : (
                      incomes.map(t => <TransactionItem key={t.id} t={t} onToggle={toggleStatus} onDelete={handleDelete} onEdit={startEdit} />)
                  )}
              </div>
          </div>

          {/* Expense Column */}
           <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                  <h3 className="font-medium text-stone-500 uppercase text-xs tracking-wider flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-red-500" /> Saídas / Contas
                  </h3>
                   <span className="text-xs font-semibold text-red-600 bg-red-50 px-2 py-0.5 rounded-full">{formatMoney(metrics.totalExpense)}</span>
              </div>
              <div className="space-y-2">
                  {expenses.length === 0 ? (
                      <div className="text-center py-10 border border-dashed border-stone-200 rounded-lg">
                          <p className="text-xs text-stone-400">Nenhuma conta cadastrada.</p>
                      </div>
                  ) : (
                      expenses.map(t => <TransactionItem key={t.id} t={t} onToggle={toggleStatus} onDelete={handleDelete} onEdit={startEdit} />)
                  )}
              </div>
          </div>
      </div>

      {/* Transaction Form Modal */}
      {isAdding && (
        <div className="fixed inset-0 bg-stone-900/20 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="px-6 py-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-medium text-stone-800">{editingId ? 'Editar Movimentação' : 'Nova Movimentação'}</h3>
                <button onClick={resetForm}><X className="w-5 h-5 text-stone-400 hover:text-stone-600" /></button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
                <div className="flex gap-4">
                    <button 
                        type="button" 
                        onClick={() => { setType('expense'); setSubCategory('custo_variavel'); }}
                        className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${type === 'expense' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-stone-50 text-stone-500 hover:bg-stone-100'}`}
                    >
                        Saída
                    </button>
                    <button 
                        type="button" 
                        onClick={() => { setType('income'); setSubCategory('ganho_variavel'); }}
                        className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${type === 'income' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-stone-50 text-stone-500 hover:bg-stone-100'}`}
                    >
                        Entrada
                    </button>
                </div>

                <div>
                    <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Descrição</label>
                    <input autoFocus required type="text" value={description} onChange={e => setDescription(e.target.value)} 
                        className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500" placeholder="Ex: Supermercado Semanal" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Valor</label>
                        <input required type="number" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} 
                            className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500" placeholder="0,00" />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Data</label>
                        <input required type="date" value={date} onChange={e => setDate(e.target.value)} 
                            className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500" />
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Categoria</label>
                        <select value={category} onChange={e => setCategory(e.target.value)} 
                            className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500">
                            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Tipo / Sub-cat</label>
                        <select value={subCategory} onChange={e => setSubCategory(e.target.value as FinancialSubCategory)} 
                            className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500">
                            {SUB_CATEGORIES.filter(s => s.type === type).map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                        </select>
                    </div>
                </div>

                <button type="submit" className="w-full bg-stone-800 text-white py-2.5 rounded-md font-medium text-sm hover:bg-stone-700 mt-2">
                    {editingId ? 'Atualizar Transação' : 'Salvar Transação'}
                </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default Financial;