import React, { useState } from 'react';
import { Note } from '../types';
import { Plus, Search, Trash2, ArrowLeft } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface NotesProps {
  notes: Note[];
  setNotes: (notes: Note[]) => void;
}

const Notes: React.FC<NotesProps> = ({ notes, setNotes }) => {
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const activeNotes = notes.filter(n => !n.archived).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  const filteredNotes = activeNotes.filter(n => n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase()));

  const selectedNote = notes.find(n => n.id === selectedNoteId);

  const createNote = () => {
      const newNote: Note = {
          id: uuidv4(),
          title: 'Nota Sem Título',
          content: '',
          tags: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          archived: false
      };
      setNotes([newNote, ...notes]);
      setSelectedNoteId(newNote.id);
  };

  const updateNote = (id: string, updates: Partial<Note>) => {
      setNotes(notes.map(n => n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n));
  };

  const deleteNote = (id: string) => {
      setNotes(notes.map(n => n.id === id ? { ...n, archived: true } : n));
      if (selectedNoteId === id) setSelectedNoteId(null);
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex animate-fade-in bg-white border border-stone-200 rounded-lg shadow-sm overflow-hidden">
        {/* List Sidebar */}
        <div className={`w-full md:w-80 border-r border-stone-200 flex flex-col bg-stone-50 ${selectedNoteId ? 'hidden md:flex' : 'flex'}`}>
            <div className="p-4 border-b border-stone-200 bg-white">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="font-medium text-stone-800">Notas</h2>
                    <button onClick={createNote} className="p-1 hover:bg-stone-100 rounded text-stone-600"><Plus className="w-5 h-5" /></button>
                </div>
                <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
                    <input 
                        type="text" 
                        placeholder="Buscar..." 
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 text-sm bg-white border-none rounded-md focus:ring-1 focus:ring-stone-300 outline-none"
                    />
                </div>
            </div>
            <div className="flex-1 overflow-y-auto">
                {filteredNotes.map(note => (
                    <div 
                        key={note.id} 
                        onClick={() => setSelectedNoteId(note.id)}
                        className={`p-4 border-b border-stone-100 cursor-pointer transition-colors hover:bg-stone-100 ${selectedNoteId === note.id ? 'bg-white border-l-4 border-l-stone-800' : 'border-l-4 border-l-transparent'}`}
                    >
                        <h4 className={`text-sm font-medium mb-1 truncate ${!note.title ? 'text-stone-400 italic' : 'text-stone-800'}`}>
                            {note.title || 'Nota Sem Título'}
                        </h4>
                        <p className="text-xs text-stone-500 truncate">{note.content || 'Sem texto adicional'}</p>
                        <span className="text-[10px] text-stone-400 mt-2 block">{new Date(note.updatedAt).toLocaleDateString('pt-BR')}</span>
                    </div>
                ))}
            </div>
        </div>

        {/* Editor Area */}
        <div className={`flex-1 flex flex-col bg-white ${!selectedNoteId ? 'hidden md:flex' : 'flex'}`}>
            {selectedNote ? (
                <>
                    <div className="p-4 border-b border-stone-100 flex justify-between items-center">
                        <button onClick={() => setSelectedNoteId(null)} className="md:hidden text-stone-500"><ArrowLeft className="w-5 h-5" /></button>
                        <span className="text-xs text-stone-400">Editado em {new Date(selectedNote.updatedAt).toLocaleString('pt-BR')}</span>
                        <button onClick={() => deleteNote(selectedNote.id)} className="text-stone-300 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-8 max-w-3xl mx-auto w-full">
                        <input 
                            type="text" 
                            value={selectedNote.title} 
                            onChange={(e) => updateNote(selectedNote.id, { title: e.target.value })}
                            placeholder="Título da Nota"
                            className="bg-white text-3xl font-bold text-stone-800 w-full outline-none placeholder-stone-300 mb-6 bg-transparent"
                        />
                        <textarea 
                            value={selectedNote.content}
                            onChange={(e) => updateNote(selectedNote.id, { content: e.target.value })}
                            placeholder="Comece a escrever..."
                            className="bg-white w-full h-[calc(100%-100px)] resize-none outline-none text-stone-700 leading-relaxed text-lg placeholder-stone-200 bg-transparent font-sans"
                        />
                    </div>
                </>
            ) : (
                <div className="flex-1 flex items-center justify-center text-stone-300">
                    <div className="text-center">
                        <p>Selecione uma nota ou crie uma nova.</p>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default Notes;