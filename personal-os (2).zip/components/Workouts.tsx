import React, { useState, useMemo } from 'react';
import { Workout } from '../types';
import { Plus, ChevronLeft, ChevronRight, CheckCircle2, Circle, Link as LinkIcon, Trash2, X } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface WorkoutsProps {
  workouts: Workout[];
  setWorkouts: (workouts: Workout[]) => void;
}

const Workouts: React.FC<WorkoutsProps> = ({ workouts, setWorkouts }) => {
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is Sunday
    const monday = new Date(d.setDate(diff));
    return monday;
  });

  const [isAdding, setIsAdding] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [newWorkout, setNewWorkout] = useState({ title: '', link: '' });

  // Generate Week Days
  const weekDays = useMemo(() => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(currentWeekStart);
      d.setDate(currentWeekStart.getDate() + i);
      days.push({
        date: d.toISOString().split('T')[0],
        dayName: d.toLocaleDateString('pt-BR', { weekday: 'long' }),
        dayNum: d.getDate(),
        isToday: new Date().toISOString().split('T')[0] === d.toISOString().split('T')[0]
      });
    }
    return days;
  }, [currentWeekStart]);

  const changeWeek = (direction: 'prev' | 'next') => {
    const newStart = new Date(currentWeekStart);
    newStart.setDate(currentWeekStart.getDate() + (direction === 'next' ? 7 : -7));
    setCurrentWeekStart(newStart);
  };

  const goToToday = () => {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    setCurrentWeekStart(new Date(d.setDate(diff)));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWorkout.title || !selectedDate) return;

    const workout: Workout = {
      id: uuidv4(),
      title: newWorkout.title,
      link: newWorkout.link,
      date: selectedDate,
      completed: false
    };

    setWorkouts([...workouts, workout]);
    setNewWorkout({ title: '', link: '' });
    setIsAdding(false);
  };

  const toggleWorkout = (id: string) => {
    setWorkouts(workouts.map(w => w.id === id ? { ...w, completed: !w.completed } : w));
  };

  const deleteWorkout = (id: string) => {
    if (confirm('Remover este treino?')) {
      setWorkouts(workouts.filter(w => w.id !== id));
    }
  };

  const openAddModal = (date: string) => {
    setSelectedDate(date);
    setIsAdding(true);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in pb-10">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-medium text-stone-800">Treinos</h2>
          <p className="text-stone-400 text-sm mt-1">Planejamento semanal de exercícios.</p>
        </div>
        <div className="flex items-center bg-white border border-stone-200 rounded-lg p-1 shadow-sm">
          <button onClick={() => changeWeek('prev')} className="p-2 hover:bg-stone-50 rounded text-stone-500"><ChevronLeft className="w-5 h-5" /></button>
          <button onClick={goToToday} className="px-4 text-sm font-medium text-stone-700 hover:text-stone-900">Hoje</button>
          <div className="h-4 w-px bg-stone-200 mx-1"></div>
          <span className="px-4 text-sm text-stone-500 font-medium capitalize">
             {currentWeekStart.toLocaleDateString('pt-BR', { month: 'short' })}
          </span>
          <button onClick={() => changeWeek('next')} className="p-2 hover:bg-stone-50 rounded text-stone-500"><ChevronRight className="w-5 h-5" /></button>
        </div>
      </div>

      {/* Week Grid */}
      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {weekDays.map((day) => {
          const dayWorkouts = workouts.filter(w => w.date === day.date);
          
          return (
            <div key={day.date} className={`flex flex-col h-full min-h-[300px] rounded-xl border transition-all ${day.isToday ? 'bg-white border-stone-300 shadow-md ring-1 ring-stone-200' : 'bg-stone-50/50 border-stone-200'}`}>
              
              {/* Day Header */}
              <div className={`p-3 border-b border-stone-100 flex flex-col items-center ${day.isToday ? 'bg-stone-100/50' : ''}`}>
                <span className={`text-[10px] uppercase font-bold tracking-wider ${day.isToday ? 'text-stone-800' : 'text-stone-400'}`}>
                  {day.dayName.split('-')[0]}
                </span>
                <span className={`text-xl font-light mt-1 ${day.isToday ? 'text-stone-900' : 'text-stone-500'}`}>
                  {day.dayNum}
                </span>
              </div>

              {/* Workouts List */}
              <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                {dayWorkouts.map(w => (
                  <div key={w.id} className={`group relative p-3 rounded-lg border transition-all ${w.completed ? 'bg-emerald-50/50 border-emerald-100' : 'bg-white border-stone-100 shadow-sm hover:border-stone-300'}`}>
                    <div className="flex items-start gap-2">
                      <button 
                        onClick={() => toggleWorkout(w.id)}
                        className={`mt-0.5 flex-shrink-0 transition-colors ${w.completed ? 'text-emerald-500' : 'text-stone-300 hover:text-stone-500'}`}
                      >
                        {w.completed ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                      </button>
                      <div className="flex-1 min-w-0">
                         <p className={`text-sm font-medium leading-tight ${w.completed ? 'text-stone-400 line-through' : 'text-stone-800'}`}>
                           {w.title}
                         </p>
                         {w.link && (
                           <a href={w.link} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-[10px] text-blue-500 mt-1.5 hover:underline w-max">
                             <LinkIcon className="w-3 h-3" /> Abrir Link
                           </a>
                         )}
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => deleteWorkout(w.id)}
                      className="absolute top-2 right-2 text-stone-300 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity p-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add Button */}
              <button 
                onClick={() => openAddModal(day.date)}
                className="m-2 p-2 flex items-center justify-center gap-2 rounded-lg border border-dashed border-stone-300 text-stone-400 hover:text-stone-600 hover:bg-stone-100 hover:border-stone-400 transition-all text-xs font-medium"
              >
                <Plus className="w-3 h-3" /> Adicionar
              </button>
            </div>
          );
        })}
      </div>

      {/* Add Modal */}
      {isAdding && (
        <div className="fixed inset-0 bg-stone-900/20 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden animate-in fade-in zoom-in duration-200">
             <div className="px-5 py-3 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-medium text-stone-800">Adicionar Treino</h3>
                <button onClick={() => setIsAdding(false)}><X className="w-5 h-5 text-stone-400 hover:text-stone-600" /></button>
            </div>
            <form onSubmit={handleSave} className="p-5 space-y-4">
               <div>
                  <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Nome do Treino</label>
                  <input 
                    autoFocus 
                    required 
                    type="text" 
                    placeholder="Ex: Treino A - Peito e Tríceps"
                    value={newWorkout.title} 
                    onChange={e => setNewWorkout({...newWorkout, title: e.target.value})} 
                    className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-sm text-stone-800 focus:outline-none focus:border-stone-500" 
                  />
               </div>
               <div>
                  <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Link (Opcional)</label>
                  <input 
                    type="url" 
                    placeholder="https://youtube.com/..."
                    value={newWorkout.link} 
                    onChange={e => setNewWorkout({...newWorkout, link: e.target.value})} 
                    className="w-full border border-stone-200 bg-white rounded-md px-3 py-2 text-sm text-stone-800 focus:outline-none focus:border-stone-500" 
                  />
               </div>
               <div className="pt-2">
                 <button type="submit" className="w-full bg-stone-800 text-white py-2 rounded-md font-medium text-sm hover:bg-stone-700">
                    Salvar na Agenda
                 </button>
               </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default Workouts;