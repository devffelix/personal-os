import React, { useState, useMemo } from 'react';
import { Habit } from '../types';
import { Plus, Trash2, X, Pencil, Clock } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface HabitsProps {
  habits: Habit[];
  setHabits: (habits: Habit[]) => void;
}

const Habits: React.FC<HabitsProps> = ({ habits, setHabits }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Form State
  const [title, setTitle] = useState('');
  const [time, setTime] = useState('');

  const today = new Date().toISOString().split('T')[0];
  
  // Generate last 7 days for the grid
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i)); // 6 days ago to today
    return d.toISOString().split('T')[0];
  });

  const resetForm = () => {
    setTitle('');
    setTime('');
    setEditingId(null);
    setIsFormOpen(false);
  };

  const startCreate = () => {
    resetForm();
    setIsFormOpen(true);
  };

  const startEdit = (habit: Habit) => {
    setTitle(habit.title);
    setTime(habit.time || '');
    setEditingId(habit.id);
    setIsFormOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (editingId) {
      // Update existing
      setHabits(habits.map(h => h.id === editingId ? { ...h, title, time } : h));
    } else {
      // Create new
      if (habits.filter(h => !h.archived).length >= 7) {
          alert("Regra de simplicidade: Máximo de 7 hábitos ativos permitidos.");
          return;
      }

      const newHabit: Habit = {
        id: uuidv4(),
        title,
        time,
        frequency: 'diário',
        completedDates: [],
        archived: false,
      };
      setHabits([...habits, newHabit]);
    }
    resetForm();
  };

  const toggleDate = (habitId: string, date: string) => {
    setHabits(habits.map(h => {
      if (h.id !== habitId) return h;
      const isCompleted = h.completedDates.includes(date);
      return {
        ...h,
        completedDates: isCompleted
          ? h.completedDates.filter(d => d !== date)
          : [...h.completedDates, date]
      };
    }));
  };

  const deleteHabit = (id: string) => {
    if(confirm('Arquivar este hábito?')) {
        setHabits(habits.map(h => h.id === id ? { ...h, archived: true } : h));
    }
  };

  const activeHabits = useMemo(() => {
    return habits
      .filter(h => !h.archived)
      .sort((a, b) => {
        // Sort by time, then by title. Habits without time go last.
        if (!a.time && !b.time) return a.title.localeCompare(b.title);
        if (!a.time) return 1;
        if (!b.time) return -1;
        return a.time.localeCompare(b.time);
      });
  }, [habits]);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-medium text-stone-800">Hábitos</h2>
          <p className="text-stone-400 text-sm mt-1">Consistência acima de intensidade. Máx 7.</p>
        </div>
        <button 
          onClick={startCreate}
          disabled={!isFormOpen && activeHabits.length >= 7}
          className="flex items-center px-4 py-2 bg-stone-800 text-white text-sm font-medium rounded-md hover:bg-stone-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" /> Novo Hábito
        </button>
      </div>

      {isFormOpen && (
        <form onSubmit={handleSave} className="bg-white p-4 border border-stone-200 rounded-lg flex flex-col md:flex-row items-center gap-4 shadow-sm">
           <div className="flex-1 w-full">
              <label className="block text-[10px] font-medium text-stone-400 uppercase mb-1">Hábito</label>
              <input
                autoFocus
                type="text"
                placeholder="ex: Ler 30 mins"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full bg-white border border-stone-200 rounded px-3 py-2 outline-none text-stone-800 placeholder-stone-400 text-sm focus:border-stone-400"
              />
           </div>
           
           <div className="w-full md:w-32">
              <label className="block text-[10px] font-medium text-stone-400 uppercase mb-1">Horário</label>
              <input
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full bg-white border border-stone-200 rounded px-2 py-2 outline-none text-stone-800 text-sm focus:border-stone-400"
              />
           </div>

          <div className="flex items-center gap-2 mt-4 md:mt-0 pt-3 md:pt-0">
            <button type="button" onClick={resetForm} className="p-2 text-stone-400 hover:text-stone-600">
                <X className="w-5 h-5" />
            </button>
            <button type="submit" className="px-4 py-2 bg-stone-800 text-white text-xs font-medium rounded hover:bg-stone-700 whitespace-nowrap">
                {editingId ? 'Atualizar' : 'Salvar'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-white border border-stone-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="bg-stone-50 border-b border-stone-200">
              <th className="text-left py-4 px-6 font-medium text-stone-500 text-xs uppercase tracking-wider">Hábito</th>
              {last7Days.map((date, i) => (
                <th key={date} className="py-4 px-2 font-medium text-stone-500 text-xs text-center w-12">
                   <div className="flex flex-col items-center">
                       <span className="text-[10px]">{new Date(date).toLocaleDateString('pt-BR', { weekday: 'narrow' })}</span>
                       <span className={`mt-1 ${date === today ? 'text-stone-900 font-bold' : ''}`}>
                           {new Date(date).getDate()}
                       </span>
                   </div>
                </th>
              ))}
              <th className="w-20"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {activeHabits.length === 0 ? (
                <tr>
                    <td colSpan={9} className="py-8 text-center text-stone-400 text-sm">
                        Nenhum hábito ativo. Crie um para começar seu sistema.
                    </td>
                </tr>
            ) : (
                activeHabits.map(habit => (
                <tr key={habit.id} className="group hover:bg-stone-50 transition-colors">
                    <td className="py-4 px-6">
                        <div className="flex flex-col">
                            <span className="text-sm font-medium text-stone-800">{habit.title}</span>
                            {habit.time && (
                                <span className="flex items-center text-[10px] text-stone-400 mt-0.5">
                                    <Clock className="w-3 h-3 mr-1" />
                                    {habit.time}
                                </span>
                            )}
                        </div>
                    </td>
                    {last7Days.map(date => {
                    const isDone = habit.completedDates.includes(date);
                    return (
                        <td key={date} className="py-4 px-2 text-center">
                        <button
                            onClick={() => toggleDate(habit.id, date)}
                            className={`w-6 h-6 rounded-md border transition-all duration-200 flex items-center justify-center mx-auto ${
                            isDone 
                                ? 'bg-stone-800 border-stone-800 text-white' 
                                : 'bg-transparent border-stone-200 hover:border-stone-400'
                            }`}
                        >
                            {isDone && <span className="w-1.5 h-1.5 bg-white rounded-full"></span>}
                        </button>
                        </td>
                    );
                    })}
                    <td className="py-4 px-2 text-right opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="flex items-center justify-end gap-1 mr-2">
                             <button onClick={() => startEdit(habit)} className="text-stone-300 hover:text-stone-600 p-1">
                                <Pencil className="w-4 h-4" />
                            </button>
                            <button onClick={() => deleteHabit(habit.id)} className="text-stone-300 hover:text-red-400 p-1">
                                <Trash2 className="w-4 h-4" />
                            </button>
                        </div>
                    </td>
                </tr>
                ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Habits;