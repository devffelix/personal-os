import React, { useState } from 'react';
import { Lead, LeadStatus } from '../types';
import { Plus, Search, MoreHorizontal, Calendar, ArrowRight } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface LeadsProps {
  leads: Lead[];
  setLeads: (leads: Lead[]) => void;
}

const Leads: React.FC<LeadsProps> = ({ leads, setLeads }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Form State
  const [formData, setFormData] = useState<Partial<Lead>>({
    status: 'Lead',
    value: 0
  });

  const statuses: LeadStatus[] = ['Lead', 'Contatado', 'Reunião', 'Proposta', 'Fechado', 'Perdido'];
  const activeLeads = leads.filter(l => !l.archived);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.nextAction) return;

    if (editingId) {
        setLeads(leads.map(l => l.id === editingId ? { ...l, ...formData } as Lead : l));
        setEditingId(null);
    } else {
        const newLead: Lead = {
            id: uuidv4(),
            name: formData.name,
            origin: formData.origin || 'Direto',
            product: formData.product || 'Serviços',
            value: Number(formData.value) || 0,
            status: formData.status as LeadStatus || 'Lead',
            lastAction: new Date().toISOString(),
            nextAction: formData.nextAction,
            archived: false,
        };
        setLeads([...leads, newLead]);
    }
    setIsAdding(false);
    setFormData({ status: 'Lead', value: 0 });
  };

  const startEdit = (lead: Lead) => {
      setFormData(lead);
      setEditingId(lead.id);
      setIsAdding(true);
  };

  const deleteLead = (id: string) => {
      if(confirm('Arquivar este lead?')) {
        setLeads(leads.map(l => l.id === id ? { ...l, archived: true } : l));
      }
  }

  // Visual Helper for Status
  const getStatusColor = (status: LeadStatus) => {
      switch(status) {
          case 'Lead': return 'bg-stone-100 text-stone-600';
          case 'Contatado': return 'bg-blue-50 text-blue-700';
          case 'Reunião': return 'bg-purple-50 text-purple-700';
          case 'Proposta': return 'bg-amber-50 text-amber-700';
          case 'Fechado': return 'bg-emerald-50 text-emerald-700';
          case 'Perdido': return 'bg-red-50 text-red-700';
          default: return 'bg-stone-100 text-stone-600';
      }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-medium text-stone-800">Leads</h2>
          <p className="text-stone-400 text-sm mt-1">Pipeline minimalista. Foco no próximo passo.</p>
        </div>
        <button 
          onClick={() => { setEditingId(null); setFormData({ status: 'Lead', value: 0}); setIsAdding(true); }}
          className="flex items-center px-4 py-2 bg-stone-800 text-white text-sm font-medium rounded-md hover:bg-stone-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" /> Adicionar Lead
        </button>
      </div>

      {/* Add/Edit Modal (Inline for simplicity) */}
      {isAdding && (
        <div className="fixed inset-0 bg-stone-900/20 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
                <div className="px-6 py-4 border-b border-stone-100 flex justify-between items-center">
                    <h3 className="font-medium text-stone-800">{editingId ? 'Editar Lead' : 'Novo Lead'}</h3>
                    <button onClick={() => setIsAdding(false)}><span className="text-2xl font-light text-stone-400">&times;</span></button>
                </div>
                <form onSubmit={handleSave} className="p-6 space-y-4">
                    <div>
                        <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Nome</label>
                        <input required type="text" className="bg-white w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-stone-500" 
                            value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Produto</label>
                            <input type="text" className="bg-white w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-stone-500" 
                                value={formData.product || ''} onChange={e => setFormData({...formData, product: e.target.value})} />
                        </div>
                         <div>
                            <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Valor (R$)</label>
                            <input type="number" className="bg-white w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-stone-500" 
                                value={formData.value || 0} onChange={e => setFormData({...formData, value: Number(e.target.value)})} />
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                             <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Status</label>
                             <select className="bg-white w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-stone-500"
                                value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as LeadStatus})}>
                                {statuses.map(s => <option key={s} value={s}>{s}</option>)}
                             </select>
                        </div>
                         <div>
                             <label className="block text-xs font-medium text-stone-500 uppercase mb-1 text-stone-800 font-bold">Data Próxima Ação</label>
                             <input required type="date" className="bg-white w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-stone-500"
                                value={formData.nextAction ? formData.nextAction.split('T')[0] : ''} onChange={e => setFormData({...formData, nextAction: e.target.value})} />
                        </div>
                    </div>
                    <button type="submit" className="w-full bg-stone-800 text-white py-2 rounded-md font-medium text-sm hover:bg-stone-700">Salvar Lead</button>
                </form>
            </div>
        </div>
      )}

      {/* List View */}
      <div className="bg-white border border-stone-200 rounded-lg overflow-hidden shadow-sm">
        <table className="w-full text-left">
            <thead className="bg-stone-50 border-b border-stone-200">
                <tr>
                    <th className="px-6 py-3 text-xs font-medium text-stone-500 uppercase tracking-wider">Lead</th>
                    <th className="px-6 py-3 text-xs font-medium text-stone-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-xs font-medium text-stone-500 uppercase tracking-wider">Valor</th>
                    <th className="px-6 py-3 text-xs font-medium text-stone-500 uppercase tracking-wider">Próxima Ação</th>
                    <th className="px-6 py-3 text-xs font-medium text-stone-500 uppercase tracking-wider text-right">Ações</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
                {activeLeads.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-8 text-stone-400 text-sm">Nenhum lead no pipeline.</td></tr>
                ) : (
                    activeLeads
                    .sort((a, b) => new Date(a.nextAction).getTime() - new Date(b.nextAction).getTime())
                    .map(lead => {
                        const isOverdue = new Date(lead.nextAction) < new Date(new Date().toISOString().split('T')[0]);
                        return (
                            <tr key={lead.id} className="group hover:bg-stone-50 transition-colors cursor-pointer" onClick={() => startEdit(lead)}>
                                <td className="px-6 py-4">
                                    <div className="text-sm font-medium text-stone-900">{lead.name}</div>
                                    <div className="text-xs text-stone-400">{lead.product} • {lead.origin}</div>
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 text-[10px] font-semibold rounded-full uppercase tracking-wide ${getStatusColor(lead.status)}`}>
                                        {lead.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-sm text-stone-600">
                                    R$ {lead.value.toLocaleString('pt-BR')}
                                </td>
                                <td className="px-6 py-4">
                                    <div className={`flex items-center gap-2 text-sm ${isOverdue ? 'text-red-600 font-medium' : 'text-stone-600'}`}>
                                        <Calendar className="w-3 h-3" />
                                        {new Date(lead.nextAction).toLocaleDateString('pt-BR')}
                                    </div>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); deleteLead(lead.id); }}
                                        className="text-stone-300 hover:text-red-500 p-2"
                                    >
                                        <span className="text-xs">Arquivar</span>
                                    </button>
                                </td>
                            </tr>
                        );
                    })
                )}
            </tbody>
        </table>
      </div>
    </div>
  );
};

export default Leads;