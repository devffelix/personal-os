import React, { useMemo, useState } from 'react';
import { Habit, Lead, Project, Settings, View, Transaction, Book } from '../types';
import { Target, CheckSquare, ArrowRight, Activity, Zap, ArrowUpRight, Briefcase, BookOpen, Plus, X, BarChart3, TrendingUp } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface DashboardProps {
  habits: Habit[];
  leads: Lead[];
  projects: Project[];
  settings: Settings;
  transactions: Transaction[];
  books: Book[];
  onUpdateBooks: (books: Book[]) => void;
  onNavigate: (view: View) => void;
  onToggleHabit: (id: string, date: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  habits, 
  leads, 
  projects, 
  settings, 
  transactions,
  books,
  onUpdateBooks,
  onNavigate, 
  onToggleHabit 
}) => {
  const [isAddingBook, setIsAddingBook] = useState(false);
  const [newBook, setNewBook] = useState({ title: '', pages: '', cover: '' });
  const today = new Date().toISOString().split('T')[0];

  // Logic: Get Habits not done today
  const pendingHabits = useMemo(() => {
    return habits
      .filter(h => !h.archived)
      .map(h => ({
        ...h,
        doneToday: h.completedDates.includes(today)
      }))
      .sort((a, b) => {
        if (a.doneToday === b.doneToday) {
            if (!a.time) return 1;
            if (!b.time) return -1;
            return a.time.localeCompare(b.time);
        }
        return a.doneToday ? 1 : -1; // Done items go to bottom
      });
  }, [habits, today]);

  // Logic: Leads with next action today or past due
  const urgentLeads = useMemo(() => {
    return leads
      .filter(l => !l.archived && l.status !== 'Fechado' && l.status !== 'Perdido')
      .sort((a, b) => new Date(a.nextAction).getTime() - new Date(b.nextAction).getTime())
      .slice(0, 4);
  }, [leads]);

  // Logic: Active Projects
  const activeProjects = useMemo(() => {
    return projects
      .filter(p => p.status === 'Ativo' && !p.archived)
      .slice(0, 4);
  }, [projects]);

  // Logic: Active Books
  const currentBooks = useMemo(() => {
      return books.filter(b => b.status === 'lendo');
  }, [books]);

  // Logic: Financial Chart Data (Last 6 months)
  const chartData = useMemo(() => {
      const last6Months = Array.from({ length: 6 }, (_, i) => {
          const d = new Date();
          d.setMonth(d.getMonth() - (5 - i));
          return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      });

      const data = last6Months.map(month => {
          const monthTrans = transactions.filter(t => t.date.startsWith(month));
          const income = monthTrans.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
          const expense = monthTrans.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
          return { month, income, expense, label: new Date(month + '-01').toLocaleDateString('pt-BR', { month: 'short' }) };
      });
      return data;
  }, [transactions]);

  // Book Handlers
  const handleAddBook = (e: React.FormEvent) => {
      e.preventDefault();
      if(!newBook.title || !newBook.pages) return;
      
      const book: Book = {
          id: uuidv4(),
          title: newBook.title,
          totalPages: Number(newBook.pages),
          pagesRead: 0,
          coverUrl: newBook.cover,
          status: 'lendo'
      };
      onUpdateBooks([...books, book]);
      setNewBook({ title: '', pages: '', cover: '' });
      setIsAddingBook(false);
  };

  const addPages = (bookId: string, amount: number) => {
      onUpdateBooks(books.map(b => {
          if (b.id !== bookId) return b;
          const newRead = Math.min(b.pagesRead + amount, b.totalPages);
          const isFinished = newRead >= b.totalPages;
          return { ...b, pagesRead: newRead, status: isFinished ? 'lido' : 'lendo' };
      }));
  };

  // Helper for Chart SVG
  const maxVal = Math.max(...chartData.map(d => Math.max(d.income, d.expense, 100))); // Avoid div/0
  const chartHeight = 100;
  const chartWidth = 100; // percent

  return (
    <div className="max-w-7xl mx-auto animate-fade-in pb-10">
      
      {/* Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 auto-rows-[minmax(160px,auto)]">
        
        {/* 1. HERO BLOCK (Welcome & Goal) - Spans 8 cols */}
        <div className="col-span-1 md:col-span-8 bg-stone-900 rounded-2xl p-6 text-stone-50 flex flex-col justify-between shadow-lg relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-32 bg-stone-800 rounded-full blur-3xl opacity-20 -mr-16 -mt-16 pointer-events-none"></div>
            
            <div className="flex justify-between items-start z-10">
                <div>
                    <h2 className="text-stone-400 font-light text-lg">Bom dia, {settings.userName}</h2>
                    <p className="text-xs text-stone-500 mt-1">{new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
                </div>
                <div className="p-2 bg-stone-800 rounded-lg">
                    <Target className="w-5 h-5 text-emerald-400" />
                </div>
            </div>

            <div className="mt-6 z-10">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-widest mb-2 block">North Star Anual</span>
                <h1 className="text-2xl md:text-3xl font-medium leading-tight max-w-2xl">
                    "{settings.yearlyGoal || 'Defina sua meta principal'}"
                </h1>
            </div>
        </div>

        {/* 2. DAILY FOCUS - Spans 4 cols */}
        <div className="col-span-1 md:col-span-4 bg-white rounded-2xl p-6 border border-stone-200 shadow-sm flex flex-col">
            <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-stone-800 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-500" /> Foco do Dia
                </h3>
            </div>
            <div className="flex-1 flex flex-col justify-center space-y-3">
                <div className="flex items-start gap-3 p-2 rounded-lg bg-stone-50 border border-stone-100">
                    <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-stone-800 shrink-0" />
                    <span className="text-sm text-stone-700 font-medium">Executar o plano de vendas</span>
                </div>
                <div className="flex items-start gap-3 p-2 rounded-lg bg-stone-50 border border-stone-100">
                    <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-stone-400 shrink-0" />
                    <span className="text-sm text-stone-600">Zerar pendências financeiras</span>
                </div>
            </div>
        </div>

        {/* 3. FINANCIAL CHART (New) - Spans 8 cols */}
        <div className="col-span-1 md:col-span-8 bg-white rounded-2xl p-5 border border-stone-200 shadow-sm flex flex-col relative overflow-hidden">
             <div className="flex items-center justify-between mb-4 z-10">
                <h3 className="font-semibold text-stone-800 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-stone-400" /> Fluxo de Caixa (6 Meses)
                </h3>
                <button onClick={() => onNavigate('financial')} className="p-1 hover:bg-stone-100 rounded-full text-stone-400 transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                </button>
            </div>
            <div className="flex-1 flex items-end justify-between gap-2 md:gap-4 relative h-32 px-2 z-10">
                {chartData.map((d, i) => (
                    <div key={i} className="flex-1 flex flex-col justify-end items-center gap-2 group h-full">
                         <div className="w-full flex gap-1 items-end h-full justify-center">
                            {/* Income Bar */}
                            <div 
                                className="w-3 md:w-6 bg-emerald-400 rounded-t-sm transition-all duration-500 hover:bg-emerald-500"
                                style={{ height: `${(d.income / maxVal) * 100}%` }}
                                title={`Entrada: R$ ${d.income}`}
                            />
                            {/* Expense Bar */}
                             <div 
                                className="w-3 md:w-6 bg-stone-300 rounded-t-sm transition-all duration-500 hover:bg-red-400"
                                style={{ height: `${(d.expense / maxVal) * 100}%` }}
                                title={`Saída: R$ ${d.expense}`}
                            />
                         </div>
                         <span className="text-[10px] text-stone-400 uppercase">{d.label}</span>
                    </div>
                ))}
                {/* Background Grid Lines */}
                 <div className="absolute inset-0 pointer-events-none flex flex-col justify-between opacity-10">
                    <div className="w-full h-px bg-stone-900"></div>
                    <div className="w-full h-px bg-stone-900"></div>
                    <div className="w-full h-px bg-stone-900"></div>
                    <div className="w-full h-px bg-stone-900"></div>
                 </div>
            </div>
        </div>

        {/* 4. HABITS (Tall Block) - Spans 4 cols, 2 rows height */}
        <div className="col-span-1 md:col-span-4 md:row-span-2 bg-white rounded-2xl border border-stone-200 shadow-sm flex flex-col overflow-hidden">
            <div className="p-5 border-b border-stone-100 bg-stone-50/50 flex justify-between items-center">
                <h3 className="font-semibold text-stone-800 flex items-center gap-2">
                    <Activity className="w-4 h-4 text-stone-400" /> Hábitos
                </h3>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                 {pendingHabits.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-stone-400 p-4 text-center">
                        <Activity className="w-8 h-8 mb-2 opacity-20" />
                        <span className="text-sm">Nenhum hábito ativo</span>
                        <button onClick={() => onNavigate('habits')} className="text-xs text-stone-800 underline mt-2">Criar rotina</button>
                    </div>
                  ) : (
                    pendingHabits.map(habit => (
                      <div 
                        key={habit.id} 
                        className={`flex items-center justify-between p-3 rounded-xl transition-all ${habit.doneToday ? 'bg-stone-50 opacity-50' : 'hover:bg-stone-50 bg-white border border-transparent hover:border-stone-100'}`}
                      >
                        <div className="flex flex-col">
                            <span className={`text-sm font-medium ${habit.doneToday ? 'text-stone-400 line-through' : 'text-stone-800'}`}>
                                {habit.title}
                            </span>
                             {habit.time && (
                                <span className="text-[10px] text-stone-400 font-mono mt-0.5">{habit.time}</span>
                            )}
                        </div>
                        <button
                          onClick={() => onToggleHabit(habit.id, today)}
                          className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                            habit.doneToday 
                              ? 'bg-stone-800 text-white shadow-none' 
                              : 'bg-white border-2 border-stone-200 hover:border-stone-400 text-transparent shadow-sm'
                          }`}
                        >
                          <CheckSquare className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
            </div>
            <div className="p-3 border-t border-stone-100 bg-stone-50/30 text-center">
                <button onClick={() => onNavigate('habits')} className="text-xs font-medium text-stone-500 hover:text-stone-800 flex items-center justify-center gap-1 w-full">
                    Gerenciar Hábitos <ArrowRight className="w-3 h-3" />
                </button>
            </div>
        </div>

        {/* 5. READING LIST (New) - Spans 4 cols */}
        <div className="col-span-1 md:col-span-4 bg-white rounded-2xl p-5 border border-stone-200 shadow-sm flex flex-col min-h-[200px]">
             <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-stone-800 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-stone-400" /> Leitura Atual
                </h3>
                <button onClick={() => setIsAddingBook(true)} className="p-1 hover:bg-stone-100 rounded-full text-stone-400 transition-colors">
                    <Plus className="w-4 h-4" />
                </button>
            </div>
            
            {isAddingBook ? (
                <div className="bg-stone-50 p-3 rounded-lg animate-fade-in">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-medium text-stone-500">Novo Livro</span>
                        <button onClick={() => setIsAddingBook(false)}><X className="w-3 h-3 text-stone-400" /></button>
                    </div>
                    <form onSubmit={handleAddBook} className="space-y-2">
                        <input autoFocus placeholder="Título do Livro" value={newBook.title} onChange={e => setNewBook({...newBook, title: e.target.value})} className="w-full text-xs p-2 border border-stone-200 rounded outline-none" />
                        <div className="flex gap-2">
                            <input type="number" placeholder="Total Pgs" value={newBook.pages} onChange={e => setNewBook({...newBook, pages: e.target.value})} className="w-1/2 text-xs p-2 border border-stone-200 rounded outline-none" />
                            <button type="submit" className="w-1/2 bg-stone-800 text-white text-xs rounded hover:bg-stone-700">Adicionar</button>
                        </div>
                        <input placeholder="URL da Capa (Opcional)" value={newBook.cover} onChange={e => setNewBook({...newBook, cover: e.target.value})} className="w-full text-xs p-2 border border-stone-200 rounded outline-none" />
                    </form>
                </div>
            ) : currentBooks.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-stone-400 text-xs border border-dashed border-stone-200 rounded-lg p-4">
                    <BookOpen className="w-6 h-6 mb-2 opacity-20" />
                    <p>O que você vai ler?</p>
                    <button onClick={() => setIsAddingBook(true)} className="mt-2 text-stone-800 underline">Adicionar livro</button>
                </div>
            ) : (
                <div className="flex-1 space-y-4">
                    {currentBooks.map(book => (
                        <div key={book.id} className="flex gap-3">
                            {/* Cover */}
                            <div className="w-16 h-24 bg-stone-200 rounded-md shrink-0 overflow-hidden shadow-sm relative">
                                {book.coverUrl ? (
                                    <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover" />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center text-stone-400"><BookOpen className="w-6 h-6 opacity-30"/></div>
                                )}
                            </div>
                            
                            {/* Info */}
                            <div className="flex-1 flex flex-col justify-between py-1">
                                <div>
                                    <h4 className="font-medium text-stone-800 text-sm leading-tight line-clamp-2">{book.title}</h4>
                                    <span className="text-xs text-stone-500 mt-1 block">{book.pagesRead} / {book.totalPages} pgs</span>
                                </div>
                                
                                <div>
                                     {/* Progress Bar */}
                                    <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden mb-2">
                                        <div className="bg-stone-800 h-full transition-all" style={{ width: `${(book.pagesRead / book.totalPages) * 100}%` }} />
                                    </div>
                                    
                                    <button 
                                        onClick={() => addPages(book.id, 5)}
                                        className="text-[10px] bg-stone-100 hover:bg-stone-200 text-stone-600 px-2 py-1 rounded transition-colors flex items-center gap-1 w-max"
                                    >
                                        <TrendingUp className="w-3 h-3" /> +5 Pgs Lidas
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>

        {/* 6. PROJECTS - Spans 4 cols */}
        <div className="col-span-1 md:col-span-4 bg-white rounded-2xl p-5 border border-stone-200 shadow-sm flex flex-col">
             <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-stone-800 flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-stone-400" /> Projetos
                </h3>
                <button onClick={() => onNavigate('projects')} className="p-1 hover:bg-stone-100 rounded-full text-stone-400 transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                </button>
            </div>
            <div className="space-y-3 flex-1">
                 {activeProjects.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-stone-400 text-xs border border-dashed border-stone-200 rounded-lg">
                        Sem projetos ativos
                    </div>
                 ) : (
                    activeProjects.map(p => (
                        <div key={p.id} onClick={() => onNavigate('projects')} className="group flex items-center justify-between p-3 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors cursor-pointer border border-stone-100">
                            <div>
                                <h4 className="text-sm font-medium text-stone-800">{p.title}</h4>
                                <span className="text-[10px] uppercase tracking-wide text-stone-500">{p.category}</span>
                            </div>
                            <div className="w-12">
                                <div className="h-1 w-full bg-stone-200 rounded-full overflow-hidden">
                                     <div 
                                        className="h-full bg-stone-800" 
                                        style={{ width: `${p.tasks.length > 0 ? (p.tasks.filter(t => t.completed).length / p.tasks.length) * 100 : 0}%` }}
                                     />
                                </div>
                            </div>
                        </div>
                    ))
                 )}
            </div>
        </div>

        {/* 7. LEADS - Spans 4 cols */}
        <div className="col-span-1 md:col-span-4 bg-white rounded-2xl p-5 border border-stone-200 shadow-sm flex flex-col">
             <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-stone-800 flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-stone-400" /> Pipeline
                </h3>
                 <button onClick={() => onNavigate('leads')} className="p-1 hover:bg-stone-100 rounded-full text-stone-400 transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                </button>
            </div>
            <div className="space-y-3 flex-1">
                {urgentLeads.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-stone-400 text-xs border border-dashed border-stone-200 rounded-lg">
                        Pipeline vazio
                    </div>
                ) : (
                    urgentLeads.map(l => (
                        <div key={l.id} onClick={() => onNavigate('leads')} className="flex items-center justify-between cursor-pointer group">
                             <div className="flex items-center gap-3">
                                <div className={`w-2 h-2 rounded-full ${new Date(l.nextAction) < new Date(today) ? 'bg-red-500' : 'bg-stone-300'}`} />
                                <div>
                                    <p className="text-sm font-medium text-stone-800 group-hover:text-stone-600 transition-colors">{l.name}</p>
                                    <p className="text-[10px] text-stone-400">{l.status} • {new Date(l.nextAction).toLocaleDateString('pt-BR', {day: '2-digit', month: '2-digit'})}</p>
                                </div>
                             </div>
                             <span className="text-xs font-medium text-stone-600">
                                {l.value > 0 ? `R$ ${(l.value / 1000).toFixed(1)}k` : '-'}
                             </span>
                        </div>
                    ))
                )}
            </div>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;