import React from 'react';
import { View } from '../types';
import { LayoutDashboard, CheckCircle2, DollarSign, Briefcase, FileText, Settings as SettingsIcon, Wallet, Dumbbell } from 'lucide-react';

interface SidebarProps {
  currentView: View;
  onChangeView: (view: View) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  const menuItems: { id: View; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'habits', label: 'Hábitos', icon: CheckCircle2 },
    { id: 'workouts', label: 'Treinos', icon: Dumbbell },
    { id: 'leads', label: 'Leads', icon: DollarSign },
    { id: 'projects', label: 'Projetos', icon: Briefcase },
    { id: 'financial', label: 'Financeiro', icon: Wallet },
    { id: 'notes', label: 'Notas', icon: FileText },
    { id: 'settings', label: 'Configurações', icon: SettingsIcon },
  ];

  return (
    <aside className="w-64 h-screen fixed left-0 top-0 bg-stone-50 border-r border-stone-200 flex flex-col pt-8 pb-4 px-4">
      <div className="mb-8 px-2">
        <h1 className="text-sm font-semibold text-stone-400 uppercase tracking-widest">Personal OS</h1>
      </div>
      
      <nav className="space-y-1 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id)}
              className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors duration-150 group ${
                isActive
                  ? 'bg-stone-200 text-stone-900'
                  : 'text-stone-500 hover:bg-stone-100 hover:text-stone-900'
              }`}
            >
              <Icon 
                className={`mr-3 h-4 w-4 transition-colors ${isActive ? 'text-stone-800' : 'text-stone-400 group-hover:text-stone-600'}`} 
                strokeWidth={2}
              />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="px-2 mt-auto">
        <p className="text-xs text-stone-300">v1.1.0 Local</p>
      </div>
    </aside>
  );
};

export default Sidebar;