import React, { useState } from 'react';
import { Project, ProjectCategory, ProjectTask } from '../types';
import { Plus, CheckSquare, Square, Trash2, MoreVertical } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface ProjectsProps {
  projects: Project[];
  setProjects: (projects: Project[]) => void;
}

const Projects: React.FC<ProjectsProps> = ({ projects, setProjects }) => {
    const [isCreating, setIsCreating] = useState(false);
    const [newTitle, setNewTitle] = useState('');
    const [newCategory, setNewCategory] = useState<ProjectCategory>('Trabalho');

    const activeProjects = projects.filter(p => !p.archived);
    const categories: ProjectCategory[] = ['MicroSaaS', 'Trabalho', 'Relacionamento', 'Casa', 'Estudos'];

    const handleCreate = (e: React.FormEvent) => {
        e.preventDefault();
        if(!newTitle) return;
        const newProject: Project = {
            id: uuidv4(),
            title: newTitle,
            category: newCategory,
            status: 'Ativo',
            priority: 'Média',
            tasks: [],
            archived: false
        };
        setProjects([...projects, newProject]);
        setNewTitle('');
        setIsCreating(false);
    };

    const toggleTask = (projectId: string, taskId: string) => {
        setProjects(projects.map(p => {
            if(p.id !== projectId) return p;
            return {
                ...p,
                tasks: p.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t)
            };
        }));
    };

    const addTask = (projectId: string, text: string) => {
        if(!text.trim()) return;
        setProjects(projects.map(p => {
            if(p.id !== projectId) return p;
            return {
                ...p,
                tasks: [...p.tasks, { id: uuidv4(), text, completed: false }]
            };
        }));
    };

    const deleteProject = (id: string) => {
        if(confirm("Arquivar este projeto?")) {
            setProjects(projects.map(p => p.id === id ? { ...p, archived: true } : p));
        }
    }

    return (
        <div className="max-w-6xl mx-auto space-y-8 animate-fade-in">
             <div className="flex items-center justify-between">
                <div>
                <h2 className="text-2xl font-medium text-stone-800">Projetos</h2>
                <p className="text-stone-400 text-sm mt-1">Grandes objetivos. Mova-os para frente.</p>
                </div>
                <button 
                onClick={() => setIsCreating(true)}
                className="flex items-center px-4 py-2 bg-stone-800 text-white text-sm font-medium rounded-md hover:bg-stone-700 transition-colors"
                >
                <Plus className="w-4 h-4 mr-2" /> Novo Projeto
                </button>
            </div>

            {isCreating && (
                <form onSubmit={handleCreate} className="bg-white p-6 rounded-lg border border-stone-200 shadow-sm space-y-4 max-w-lg mx-auto">
                    <div>
                        <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Nome do Projeto</label>
                        <input autoFocus type="text" value={newTitle} onChange={e => setNewTitle(e.target.value)} 
                            className="bg-white w-full border border-stone-200 rounded p-2 text-sm focus:outline-none focus:border-stone-500"/>
                    </div>
                    <div>
                         <label className="block text-xs font-medium text-stone-500 uppercase mb-1">Categoria</label>
                         <div className="flex gap-2 flex-wrap">
                             {categories.map(c => (
                                 <button key={c} type="button" onClick={() => setNewCategory(c)}
                                    className={`px-3 py-1 text-xs rounded-full border transition-colors ${newCategory === c ? 'bg-stone-800 text-white border-stone-800' : 'bg-white text-stone-500 border-stone-200 hover:border-stone-400'}`}>
                                    {c}
                                 </button>
                             ))}
                         </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                        <button type="button" onClick={() => setIsCreating(false)} className="px-4 py-2 text-xs text-stone-500 hover:text-stone-800">Cancelar</button>
                        <button type="submit" className="px-4 py-2 bg-stone-800 text-white text-xs rounded hover:bg-stone-700">Criar Projeto</button>
                    </div>
                </form>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeProjects.map(project => (
                    <div key={project.id} className="bg-white border border-stone-200 rounded-lg p-5 flex flex-col shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="font-semibold text-stone-800 text-lg leading-tight">{project.title}</h3>
                                <span className="text-[10px] text-stone-400 uppercase tracking-widest">{project.category}</span>
                            </div>
                            <button onClick={() => deleteProject(project.id)} className="text-stone-300 hover:text-stone-500"><Trash2 className="w-4 h-4" /></button>
                        </div>

                        {/* Progress */}
                        <div className="mb-6">
                            <div className="flex justify-between text-xs text-stone-400 mb-1">
                                <span>Progresso</span>
                                <span>{project.tasks.length ? Math.round((project.tasks.filter(t => t.completed).length / project.tasks.length) * 100) : 0}%</span>
                            </div>
                            <div className="w-full bg-stone-100 h-1 rounded-full overflow-hidden">
                                <div className="bg-stone-800 h-full transition-all duration-300" 
                                    style={{ width: `${project.tasks.length ? (project.tasks.filter(t => t.completed).length / project.tasks.length) * 100 : 0}%` }}></div>
                            </div>
                        </div>

                        {/* Tasks */}
                        <div className="flex-1 space-y-2 mb-4">
                            {project.tasks.slice(0, 5).map(task => (
                                <div key={task.id} className="flex items-start gap-2 group cursor-pointer" onClick={() => toggleTask(project.id, task.id)}>
                                    <div className={`mt-0.5 ${task.completed ? 'text-stone-400' : 'text-stone-300 group-hover:text-stone-500'}`}>
                                        {task.completed ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                                    </div>
                                    <span className={`text-sm ${task.completed ? 'text-stone-400 line-through decoration-stone-300' : 'text-stone-700'}`}>
                                        {task.text}
                                    </span>
                                </div>
                            ))}
                            {project.tasks.length === 0 && <p className="text-xs text-stone-400 italic">Nenhuma tarefa ainda.</p>}
                        </div>

                        {/* Quick Add Task */}
                        <div className="mt-auto pt-4 border-t border-stone-100">
                            <input 
                                type="text" 
                                placeholder="+ Adicionar próximo passo" 
                                className="bg-white w-full text-xs outline-none text-stone-600 placeholder-stone-300"
                                onKeyDown={(e) => {
                                    if(e.key === 'Enter') {
                                        addTask(project.id, e.currentTarget.value);
                                        e.currentTarget.value = '';
                                    }
                                }}
                            />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Projects;