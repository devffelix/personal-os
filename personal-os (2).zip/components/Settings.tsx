import React from 'react';
import { Settings as SettingsType } from '../types';

interface SettingsProps {
  settings: SettingsType;
  saveSettings: (s: SettingsType) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, saveSettings }) => {
  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
        <h2 className="text-2xl font-medium text-stone-800">Configurações</h2>
        
        <div className="bg-white p-6 rounded-lg border border-stone-200 space-y-6">
            <div>
                <label className="block text-sm font-medium text-stone-700 mb-2">Nome de Exibição</label>
                <input 
                    type="text" 
                    value={settings.userName} 
                    onChange={e => saveSettings({ ...settings, userName: e.target.value })}
                    className="bg-white w-full border border-stone-300 rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500"
                />
            </div>
            <div>
                <label className="block text-sm font-medium text-stone-700 mb-2">Meta Anual / North Star</label>
                <input 
                    type="text" 
                    value={settings.yearlyGoal} 
                    onChange={e => saveSettings({ ...settings, yearlyGoal: e.target.value })}
                    className="bg-white w-full border border-stone-300 rounded-md px-3 py-2 text-stone-800 focus:outline-none focus:border-stone-500"
                />
                <p className="text-xs text-stone-400 mt-2">Isso aparece no seu Dashboard todos os dias.</p>
            </div>
            
            <div className="pt-4 border-t border-stone-100">
                <p className="text-xs text-stone-400">
                    Todos os dados são armazenados localmente no seu navegador. Limpar o cache removerá seus dados.
                </p>
            </div>
        </div>
    </div>
  );
};

export default Settings;